# PohLang

A beginner-focused, fully phrasal (English-like) language with an authoritative Python interpreter and an experimental Dart transpiler. There is no symbol-based mode: every program is written as readable commands.

📘 Full documentation: see the comprehensive guide at [PohLang_Guide.md](./PohLang_Guide.md).

## Release Information
- **PohLang Core**: v0.1.0 (First Experimental Release)
- **Python Interpreter**: v0.5.0 (Stable)
- **Dart Transpiler**: v0.3.5 (Fourth Experimental Release)

## Goals
- Use plain-language statements: `Write "Hello"`, `Set count to 5`, `Repeat 3 ... End`.
- Keep one clear form per concept (no synonyms like Print/Show). Use `Write`, not `Say/Print`.
- Provide a gentle path to programming concepts (variables, loops, conditionals, functions) without punctuation noise.
- Output readable Dart so learners can transition later (via the transpiler).

## Example
```
Ask for name
Write "Hello " plus name
Set count to 3
Repeat 3
	 Write "Hi"
End
If count is greater than 1 Write "Many" Otherwise Write "Few"
Make greet with who Write "Hi " plus who
Use greet with "Poh"
```

## Running a Program

Option A: Python interpreter (recommended)
1. Install: pip install pohlang
2. Run: pohlang examples/poh/hello.poh
3. Or: python -m Interpreter.run_poh examples/poh/hello.poh (from a source checkout)

Option B: Dart transpiler (experimental)
1. Ensure Dart SDK is installed.
2. Transpile without running:
	- dart run bin/pohlang.dart examples/poh/phrase_repeat.poh --no-run
3. Then run the generated Dart:
	- dart run examples/poh/phrase_repeat.dart

## Current Features
- Write, Ask for, Set, Increase, Decrease
- If/Otherwise blocks and inline If
- Repeat and While loops
- Function definition (Make/End) and calls (Use or expression calls)
- Expression support: identifiers, numbers, strings, booleans; plus/minus/times; comparisons like `is greater than`, `is less than`, `is equal to`
- Desugaring for increase/decrease
 - File and process helpers (selected operations via runtime)

## Roadmap
- Multi-line blocks with indentation (If / Repeat / Define)
- Lists, dictionaries, predicates (is even, is greater than)
- Random numbers, timers, date utilities
- Error diagnostics with suggestions & line numbers
- Optional extensions: Islamic-friendly helpers (prayer times, Hijri date, Quran recitation)
- Flutter integration examples

## Directory Structure
```
bin/             CLI entry for transpiler (Dart)
doc/             Language syntax and vocabulary
examples/        Sample PohLang programs (.poh) and generated Dart
Interpreter/     Python reference interpreter and CLI
lib/             Dart runtime for transpiled code
tests_dart/      Dart unit tests
tests_python/    Python test suite (E2E and interpreter tests)
transpiler/      Dart transpiler package and sources
```

## Contributing
Open to experiments—keep syntax consistent and simple. Prefer the phrasal form (`plus`, `minus`, `times`, `is greater than`). Avoid adding synonyms for core statements unless backed by learning outcomes.

## License
MIT
